export const environment = {
  production: true,
  API_BASE_URL:' https://www.minitwitter.com:3001/apiv1/'
};
