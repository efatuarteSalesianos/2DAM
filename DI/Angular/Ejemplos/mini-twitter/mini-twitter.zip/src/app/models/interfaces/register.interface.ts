export interface RegisterResponse {
    token: string;
    username: string;
    email: string;
    role: string;
    photoUrl: string;
    created: string;
    active: boolean;
}
