export interface TweetResponse {

}
